import { checkPassword, issueSession, cookie, json } from "./_lib.mjs";
export async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Method tidak diizinkan." });
  let body; try { body = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "Data tidak valid." }); }
  if (!checkPassword(body.password)) return json(401, { error: "Password salah." });
  return json(200, { ok: true }, { "Set-Cookie": cookie(issueSession()) });
}
