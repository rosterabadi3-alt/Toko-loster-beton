import crypto from "node:crypto";
import { json, requireAdmin } from "./_lib.mjs";
export async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Method tidak diizinkan." });
  const denied = requireAdmin(event); if (denied) return denied;
  try {
    const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) throw new Error("Konfigurasi storage belum lengkap.");
    const contentType = event.headers["content-type"] || event.headers["Content-Type"] || "";
    const boundary = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/)?.slice(1).find(Boolean);
    if (!boundary) return json(400, { error: "Upload file tidak valid." });
    const raw = Buffer.from(event.body || "", event.isBase64Encoded ? "base64" : "utf8");
    const marker = Buffer.from(`--${boundary}`);
    let file = null, filename = "product";
    let cursor = 0;
    while ((cursor = raw.indexOf(marker, cursor)) !== -1) {
      const start = raw.indexOf(Buffer.from("\r\n\r\n"), cursor);
      if (start === -1) break;
      const headerText = raw.subarray(cursor, start).toString();
      const end = raw.indexOf(marker, start + 4);
      if (end === -1) break;
      if (headerText.includes('name="file"')) {
        const nameMatch = headerText.match(/filename="([^"]*)"/);
        if (nameMatch) filename = nameMatch[1].replace(/[^a-zA-Z0-9._-]/g, "_");
        file = raw.subarray(start + 4, end - 2);
        break;
      }
      cursor = end;
    }
    if (!file?.length) return json(400, { error: "Foto tidak ditemukan." });
    if (file.length > 5 * 1024 * 1024) return json(413, { error: "Ukuran foto maksimal 5 MB." });
    const ext = filename.includes(".") ? filename.split(".").pop().toLowerCase() : "jpg";
    const mime = ({jpg:"image/jpeg",jpeg:"image/jpeg",png:"image/png",webp:"image/webp",gif:"image/gif"})[ext];
    if (!mime) return json(400, { error: "Format foto harus JPG, PNG, WEBP, atau GIF." });
    const path = `${Date.now()}-${crypto.randomBytes(5).toString("hex")}.${ext}`;
    const response = await fetch(`${url}/storage/v1/object/product-images/${path}`, {
      method: "POST", headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": mime, "x-upsert": "false" }, body: file
    });
    if (!response.ok) throw new Error(await response.text());
    return json(200, { url: `${url}/storage/v1/object/public/product-images/${path}` });
  } catch (e) { return json(500, { error: e.message || "Gagal upload foto." }); }
}
