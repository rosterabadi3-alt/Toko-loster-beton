import { isAuthenticated, json } from "./_lib.mjs";
export async function handler(event) {
  return isAuthenticated(event) ? json(200, { ok: true }) : json(401, { error: "Belum login." });
}
