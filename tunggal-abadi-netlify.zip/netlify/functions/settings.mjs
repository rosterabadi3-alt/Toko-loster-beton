import { json, requireAdmin } from "./_lib.mjs";
const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
export async function handler(event) {
  if (event.httpMethod !== "POST") return json(405, { error: "Method tidak diizinkan." });
  const denied = requireAdmin(event); if (denied) return denied;
  try {
    if (!url || !key) throw new Error("Konfigurasi database belum lengkap.");
    const body = JSON.parse(event.body || "{}");
    const allowed = ["name", "phone", "logo_url", "hero_title", "hero_desc"];
    const rows = allowed.filter(k => body[k] !== undefined).map(k => ({ key: k, value: String(body[k]) }));
    const res = await fetch(`${url}/rest/v1/store_settings?on_conflict=key`, {
      method: "POST", headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(rows)
    });
    if (!res.ok) throw new Error(await res.text());
    return json(200, { ok: true });
  } catch (e) { return json(500, { error: e.message }); }
}
