import { json, requireAdmin } from "./_lib.mjs";

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
async function db(path, options = {}) {
  if (!url || !key) throw new Error("Konfigurasi database belum lengkap.");
  const res = await fetch(`${url}/rest/v1/${path}`, {
    ...options,
    headers: {
      apikey: key, Authorization: `Bearer ${key}`,
      "Content-Type": "application/json", Prefer: options.prefer || "return=representation",
      ...(options.headers || {})
    }
  });
  const text = await res.text();
  if (!res.ok) throw new Error(text || `Database error ${res.status}`);
  return text ? JSON.parse(text) : [];
}
export async function handler(event) {
  try {
    if (event.httpMethod === "GET") {
      const [items, settings] = await Promise.all([
        db("products?select=*&order=created_at.desc"),
        db("store_settings?select=key,value")
      ]);
      const config = {};
      for (const row of settings) config[row.key] = row.value;
      return json(200, { products: items, settings: {
        name: config.name || "TUNGGAL ABADI", phone: config.phone || "087840507473",
        logo_url: config.logo_url || "", hero_title: config.hero_title || "Bangun Ruang, Ciptakan Keindahan.",
        hero_desc: config.hero_desc || "Temukan pilihan loster beton, panel dinding, bata tempel, dan bata pres untuk mempercantik serta memperkuat karakter bangunan Anda."
      } });
    }
    const denied = requireAdmin(event); if (denied) return denied;
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body || "{}");
      const allowed = ["name", "category", "price", "description", "image_url"];
      const data = Object.fromEntries(allowed.filter(k => body[k] !== undefined).map(k => [k, body[k]]));
      if (!data.name) return json(400, { error: "Nama produk wajib diisi." });
      if (body.id) data.id = body.id;
      const rows = await db("products?on_conflict=id", { method: "POST", body: JSON.stringify(data), prefer: "resolution=merge-duplicates,return=representation" });
      return json(200, { product: rows[0] });
    }
    if (event.httpMethod === "DELETE") {
      const id = event.queryStringParameters?.id;
      if (!id) return json(400, { error: "ID produk tidak ada." });
      await db(`products?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" });
      return json(200, { ok: true });
    }
    return json(405, { error: "Method tidak diizinkan." });
  } catch (e) { return json(500, { error: e.message || "Kesalahan server." }); }
}
