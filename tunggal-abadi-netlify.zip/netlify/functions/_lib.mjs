import crypto from "node:crypto";

const cookieName = "ta_admin";
const secret = process.env.SESSION_SECRET || "";
const password = process.env.ADMIN_PASSWORD || "";

function b64(value) { return Buffer.from(value).toString("base64url"); }
function sign(value) { return crypto.createHmac("sha256", secret).update(value).digest("base64url"); }

export function issueSession() {
  const payload = b64(JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 }));
  return `${payload}.${sign(payload)}`;
}
export function isAuthenticated(event) {
  if (!secret) return false;
  const raw = event.headers.cookie || event.headers.Cookie || "";
  const token = raw.split(";").map(x => x.trim()).find(x => x.startsWith(cookieName + "="))?.slice(cookieName.length + 1);
  if (!token) return false;
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return false;
  const expected = sign(payload);
  const a = Buffer.from(signature), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return false;
  try { return JSON.parse(Buffer.from(payload, "base64url").toString()).exp > Date.now(); } catch { return false; }
}
export function cookie(value, maxAge = 28800) {
  return `${cookieName}=${value}; HttpOnly; Secure; SameSite=Strict; Path=/api; Max-Age=${maxAge}`;
}
export function checkPassword(input) {
  if (!password || !input) return false;
  const a = Buffer.from(String(input)), b = Buffer.from(password);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
export function json(statusCode, body, headers = {}) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers }, body: JSON.stringify(body) };
}
export function requireAdmin(event) {
  if (!isAuthenticated(event)) return json(401, { error: "Sesi admin tidak berlaku. Silakan login kembali." });
  return null;
}
